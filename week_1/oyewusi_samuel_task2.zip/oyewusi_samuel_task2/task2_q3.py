# Input statements
name = input("Enter student's name: ")
student_class = input("Enter student's class: ")
state = input("Enter student's state of origin: ")

# output using string concatenation
print("Student " + name + " is in " + student_class + " and is from " + state + " State.")

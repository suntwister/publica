price = str(input("what is the current price of gari per paint in naira: "))
price_float = float(price)
# convert price to naira and kobo
naira = int(price_float)
print(f'The current price of gari per paint is {naira} naira 0 kobo')

# Input statements
dish = input("Enter the name of a Nigerian dish: ")
state = input("Enter the state it is popular in: ")
# output
print("Dish: " + dish + "\n State:\t" + state)

# Collecting user details
user_name = input("Kindly enter your first name: ")
user_age = input("Kindly enter your age: ")
print(f'Welcome {user_name}, you are {user_age} years old.')

# Input statements
festival = input("Enter the festival name: ")
location = input("Enter the location: ")
month = input("Enter the month it is held: ")

# Output
print("The \"" + festival + "\" festival is held in " + location + " every " + month + ".")
print("samuel is a \"" )
# Input statements
distance = float(input("Enter distance in km: "))
fare_per_km = float(input("Enter fare per km: "))

# Calculate total fare
total_fare = distance * fare_per_km

# Display total fare
print(f"The total fare is ₦{total_fare:.2f}")
